import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../Component/Home/HomeCartComponent.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'EventPage.dart';
import 'FinalPage.dart';
import 'LecturePage.dart';
import 'MidtermPage.dart';
import 'NotesPage.dart';
import 'SectionPage.dart';

class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
      child: Column(children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Orange",
              style: GoogleFonts.poppins(
                  fontSize: 25,
                  fontWeight: FontWeight.w600,
                  color: Colors.deepOrangeAccent),
            ),
            Text(
              " Digital Center",
              style: GoogleFonts.poppins(
                  fontSize: 25, fontWeight: FontWeight.w600),
            ),
          ],
        ),
        const SizedBox(
          height: 30,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Column(
              children: [
                InkWell(
                  onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => Lecture())),
                  child: homeCard(
                      SvgPicture.asset(
                        'assets/icons/lecture.svg',
                        height: 35,
                        width: 30,
                      ),
                      "Lectures"),
                ),
                const SizedBox(
                  height: 5,
                ),
                InkWell(
                  onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => Midterm())),
                  child: homeCard(
                      SvgPicture.asset(
                        'assets/icons/midterm.svg',
                        height: 35,
                        width: 30,
                      ),
                      "Midterms"),
                ),
                const SizedBox(
                  height: 5,
                ),
                InkWell(
                  onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => Events())),
                  child: homeCard(
                      SvgPicture.asset(
                        'assets/icons/event.svg',
                        height: 35,
                        width: 30,
                      ),
                      "Events"),
                ),
                const SizedBox(
                  height: 5,
                ),
              ],
            ),
            const SizedBox(width: 15),
            Column(
              children: [
                InkWell(
                  onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => Section())),
                  child: homeCard(
                      SvgPicture.asset('assets/icons/sections.svg',
                          height: 35,
                          width: 30,
                          color: Colors.deepOrangeAccent),
                      "Sections"),
                ),
                const SizedBox(
                  height: 5,
                ),
                InkWell(
                  onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => Final())),
                  child: homeCard(
                      SvgPicture.asset(
                        'assets/icons/final.svg',
                        height: 35,
                        width: 30,
                      ),
                      "Finals"),
                ),
                const SizedBox(
                  height: 5,
                ),
                InkWell(
                  onTap: () => Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => Notes())),
                  child: homeCard(
                      SvgPicture.asset(
                        'assets/icons/notes.svg',
                        height: 35,
                        width: 30,
                      ),
                      "Notes"),
                ),
                const SizedBox(
                  height: 5,
                ),
              ],
            ),
          ],
        ),
      ]),
    ));
  }
}
