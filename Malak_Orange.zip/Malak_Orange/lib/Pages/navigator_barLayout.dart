/*import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../View_Model/Block/Layout/layout_Cubit.dart';


class NevBarLayout extends StatelessWidget {
  const NevBarLayout({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => LayoutCubit(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(primarySwatch: Colors.deepOrange),
        home: BlocConsumer<LayoutCubit, LayoutStates>(
          listener: (context, state) {},
          builder: (context, state) {
            LayoutCubit myCubit = LayoutCubit.get(context);
            return Scaffold(
              body: myCubit.list[myCubit.currentIndex],
              bottomNavigationBar: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5),
                child: GNav(
                    rippleColor: Colors.white10,
                    // tab button ripple color when pressed
                    backgroundColor: Colors.white,
                    hoverColor: Colors.white10,
                    // tab button hover color
                    haptic: true,
                    // haptic feedback
                    tabBorderRadius: 15,
                    tabActiveBorder:
                        Border.all(color: Colors.white10, width: 1),
                    // tab button border
                    //tabBorder: Border.all(color: Colors.white, width: 1), // tab button border
                    //tabShadow: [BoxShadow(color: Colors.white.withOpacity(0.5), blurRadius: 8)], // tab button shadow
                    curve: Curves.easeOutExpo,
                    // tab animation curves
                    duration: const Duration(milliseconds: 900),
                    // tab animation duration
                    gap: 8,
                    // the tab button gap between icon and text
                    color: Colors.black87,
                    // unselected icon color
                    activeColor: Colors.orange,
                    // selected icon and text color
                    iconSize: 24,
                    // tab button icon size
                    tabBackgroundColor: Colors.white10.withOpacity(0.1),
                    // selected tab background color
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 7),
                    // navigation bar padding
                    selectedIndex: myCubit.currentIndex,
                    onTabChange: (value) {
                      myCubit.changeCurrent(value);
                    },
                    tabs: [
                      GButton(
                        icon: Icons.home_outlined,
                        backgroundColor: Colors.grey[200],
                        border: Border.all(color: Colors.white10),
                        borderRadius: BorderRadius.circular(30),
                        padding: const EdgeInsets.all(12),
                        text: 'Home',
                      ),
                      GButton(
                        icon: Icons.newspaper,
                        backgroundColor: Colors.grey[200],
                        border: Border.all(color: Colors.white10),
                        borderRadius: BorderRadius.circular(30),
                        padding: const EdgeInsets.all(12),
                        text: 'News',
                      ),
                      GButton(
                        icon: Icons.settings,
                        backgroundColor: Colors.grey[200],
                        border: Border.all(color: Colors.white10),
                        borderRadius: BorderRadius.circular(30),
                        padding: const EdgeInsets.all(12),
                        text: 'Settings',
                      )
                    ]),
              ),
            );
          },
        ),
      ),
    );
  }
}

*/


import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import '../view_model/Block/Layout/layout_Cubit.dart';







class NavBarLayout extends StatelessWidget {
  const NavBarLayout({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => LayoutCubit(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: BlocConsumer<LayoutCubit,LayoutStates>(

          listener: (context, state) {

          },
          builder: (context, state) {
            LayoutCubit myCubit = LayoutCubit.get(context);
            return Scaffold(
              body: myCubit.list[myCubit.currentIndex],
              bottomNavigationBar: Padding(padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5),
                child: GNav(
                    rippleColor: Colors.white10, // tab button ripple color when pressed
                    backgroundColor: Colors.white,
                    hoverColor: Colors.white10, // tab button hover color
                    haptic: true, // haptic feedback
                    tabBorderRadius: 15,
                    tabActiveBorder: Border.all(color: Colors.white10, width: 1), // tab button border
                    //tabBorder: Border.all(color: Colors.white, width: 1), // tab button border
                    //tabShadow: [BoxShadow(color: Colors.white.withOpacity(0.5), blurRadius: 8)], // tab button shadow
                    curve: Curves.easeOutExpo, // tab animation curves
                    duration: Duration(milliseconds: 900), // tab animation duration
                    gap: 8, // the tab button gap between icon and text
                    color: Colors.black87, // unselected icon color
                    activeColor: Colors.orange, // selected icon and text color
                    iconSize: 24, // tab button icon size
                    tabBackgroundColor: Colors.white10.withOpacity(0.1), // selected tab background color
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 7), // navigation bar padding
                    selectedIndex: myCubit.currentIndex,
                    onTabChange: (value){myCubit.changeCurrent(value);},
                    tabs: [
                      GButton(
                        icon: Icons.home_outlined,
                        backgroundColor: Colors.grey[200],
                        border: Border.all(color: Colors.white10),
                        borderRadius: BorderRadius.circular(30),
                        padding: EdgeInsets.all(12),
                        text: 'Home',
                      ),
                      GButton(
                        icon: Icons.newspaper,
                        backgroundColor: Colors.grey[200],
                        border: Border.all(color: Colors.white10),
                        borderRadius: BorderRadius.circular(30),
                        padding: EdgeInsets.all(12),
                        text: 'News',
                      ),
                      GButton(
                        icon: Icons.settings,
                        backgroundColor: Colors.grey[200],
                        border: Border.all(color: Colors.white10),
                        borderRadius: BorderRadius.circular(30),
                        padding: EdgeInsets.all(12),
                        text: 'Settings',
                      )
                    ]
                ),
              ),
            );
          },

        ),
      ),
    );
  }
}
