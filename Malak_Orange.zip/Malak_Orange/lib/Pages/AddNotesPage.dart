import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'NotesPage.dart';


class AddNotes extends StatelessWidget {
  const AddNotes({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          const SizedBox(
            height: 30,
          ),
          Row(
            children: [
              InkWell(
                  onTap: () => Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => Notes())),
                  child: const Icon(Icons.arrow_back_ios_new)),
              const SizedBox(
                width: 120,
              ),
              Text(
                "Add Note",
                style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w500,
                    fontSize: 30,
                    color: Colors.black,
                    letterSpacing: .5),
              ),
            ],
          ),
          const SizedBox(
            height: 50,
          ),
          SizedBox(
              width: 380,
              height: 60,
              child: TextFormField(
                decoration: InputDecoration(
                  labelText: "Title",
                  hintText: "Enter Title",
                  //prefixIcon: Icon(Icons.email_sharp, color: Colors.black54,),
                  hintStyle: const TextStyle(color: Colors.black),
                  labelStyle: const TextStyle(color: Colors.black),
                  filled: true,
                  fillColor: Colors.white,
                  enabledBorder: const OutlineInputBorder(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(16),
                        bottomRight: Radius.circular(16)),
                    borderSide: BorderSide(color: Colors.teal, width: 2),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(16),
                        bottomRight: Radius.circular(16)),
                    borderSide:
                        BorderSide(color: Colors.pinkAccent.shade100, width: 2),
                  ),
                ),
              )),
          const SizedBox(
            height: 30,
          ),
          SizedBox(
              width: 380,
              height: 60,
              child: TextFormField(
                initialValue: "2022-09-28 00:36:59.161424",
                decoration: InputDecoration(
                  labelText: "Date",
                  hintText: "2022-09-28 00:36:59.161424",
                  hintStyle: const TextStyle(color: Colors.black),
                  labelStyle: const TextStyle(color: Colors.black),
                  filled: true,
                  fillColor: Colors.white,
                  enabledBorder: const OutlineInputBorder(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(16),
                        bottomRight: Radius.circular(16)),
                    borderSide: BorderSide(color: Colors.teal, width: 2),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(16),
                        bottomRight: Radius.circular(16)),
                    borderSide:
                        BorderSide(color: Colors.pinkAccent.shade100, width: 2),
                  ),
                ),
              )),
          const SizedBox(
            height: 30,
          ),
          SizedBox(
              width: 380,
              height: 60,
              child: TextFormField(
                decoration: InputDecoration(
                  labelText: "Note",
                  hintText: "Enter Note",
                  //prefixIcon: Icon(Icons.email_sharp, color: Colors.black54,),
                  hintStyle: const TextStyle(color: Colors.black),
                  labelStyle: const TextStyle(color: Colors.black),
                  filled: true,
                  fillColor: Colors.white,
                  enabledBorder: const OutlineInputBorder(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(16),
                        bottomRight: Radius.circular(16)),
                    borderSide: BorderSide(color: Colors.teal, width: 2),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(16),
                        bottomRight: Radius.circular(16)),
                    borderSide:
                        BorderSide(color: Colors.pinkAccent.shade100, width: 2),
                  ),
                ),
              )),
          const SizedBox(
            height: 20,
          ),
          Center(
              child: ElevatedButton.icon(
                  icon: const Icon(
                    Icons.add,
                    color: Colors.black,
                    size: 24.0,
                  ),
                  label: const Text("Add",
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          color: Colors.black)),
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    primary: const Color.fromARGB(30, 52, 52, 56),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ))),
        ]),
      ),
    );
  }
}
