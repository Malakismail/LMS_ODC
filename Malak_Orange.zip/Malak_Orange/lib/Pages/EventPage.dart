import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'navigator_barLayout.dart';


class Events extends StatelessWidget {
  const Events({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            backgroundColor: Colors.white,
            leading: InkWell(
              onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => const NavBarLayout())),
              child: const Icon(
                Icons.arrow_back_ios,
                color: Colors.deepOrange,
              ),
            ),
            centerTitle: true,
            title: Text(
              "Midterms",
              style: GoogleFonts.poppins(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                textStyle: const TextStyle(
                  color: Colors.black,
                ),
              ),
            )),
        body: SfCalendar(
            view: CalendarView.month,
            initialSelectedDate: DateTime.now(),
            cellBorderColor: Colors.black,
            todayHighlightColor: Colors.deepOrange,
            appointmentTextStyle: TextStyle(fontSize: 30,
                fontWeight: FontWeight.w600,
                color: Colors.deepOrangeAccent),
            monthViewSettings: const MonthViewSettings(
                appointmentDisplayMode:
                    MonthAppointmentDisplayMode.appointment)));
  }
}
