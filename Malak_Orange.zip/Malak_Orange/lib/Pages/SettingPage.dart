import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../Component/Settings/listTileComponent.dart';
import 'FAQPage.dart';
import 'Login.dart';
import 'OurPartenerPage.dart';
import 'SupportPage.dart';
import 'TermsAndCondtion.dart';

class Setting extends StatelessWidget {
  const Setting({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(mainAxisAlignment: MainAxisAlignment.start, children: [
        const SizedBox(height: 70),
        Center(
            child: Text("Settings",
                style: GoogleFonts.roboto(
                  color: Colors.black,
                  fontWeight: FontWeight.w500,
                  fontSize: 35,
                ))),
        Column(
          children: [
            list('FAQ', const Icon(Icons.arrow_forward_ios), () {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => const FAQ()));
            }),
            const Divider(color: Colors.black26, thickness: 1),
            list('Terms & Condition', const Icon(Icons.arrow_forward_ios), () {
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) => TermsAndConditions()));
            }),
            const Divider(color: Colors.black26, thickness: 1),
            list('Our Partenrs', const Icon(Icons.arrow_forward_ios), () {
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) => OurPartner()));
            }),
            const Divider(color: Colors.black26, thickness: 1),
            list('Support', const Icon(Icons.arrow_forward_ios), () {
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) => Support()));
            }),
            const Divider(color: Colors.black26, thickness: 1),
            list(
              'Log out',
              const Icon(Icons.arrow_forward_ios),
              () {
                _showDialog(context);
              },
            )
          ],
        )
      ]),
    );
  }
}

_showDialog(BuildContext context) {
  return showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text('Log Out'),
        content: const Text('Are You Sure?'),
        actions: <Widget>[
          SizedBox(
            height: 30,
            width: 90,
            child: TextButton(
              style: TextButton.styleFrom(
                side: const BorderSide(width: 2.0, color: Colors.deepOrange),
                textStyle: Theme.of(context).textTheme.labelLarge,
              ),
              child: const Text(
                'Cancel',
                style: TextStyle(color: Colors.deepOrange),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ),
          Container(
            margin: const EdgeInsets.fromLTRB(25, 0, 25, 0),
            child: SizedBox(
              height: 30,
              width: 90,
              child: TextButton(
                style: TextButton.styleFrom(
                  backgroundColor: Colors.deepOrange,
                  side: const BorderSide(width: 2.0, color: Colors.deepOrange),
                  textStyle: Theme.of(context).textTheme.labelLarge,
                ),
                child:
                    const Text('Sure', style: TextStyle(color: Colors.white)),
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const Login()));
                },
              ),
            ),
          ),
        ],
      );
    },
  );
}
