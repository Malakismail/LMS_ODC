import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import '../Component/LogIn&SignUp/elevatedButtonWithBorder.dart';
import '../Component/LogIn&SignUp/textFormField.dart';
import '../Component/LogIn&SignUp/textFormFieldWithIcon.dart';
import '../Component/elevatedButton.dart';
import '../Component/LogoComponent.dart';
import '../view_model/Block/SignUp/SignUP_State.dart';
import '../view_model/Block/SignUp/SignUp_Cubit.dart';


List<String> gender = <String>['Female', 'Male'];
List<String> university = <String>['ASU', 'AUC', 'CAD', 'ALEX', 'ASWU'];
List<String> grade = <String>['Grade1', 'Grade2', 'Grade3', 'Grade4'];

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  String? value;
  @override
  String gendervalue = gender.first;
  String UniVal = university.first;
  String gradVal = grade.first;

  Widget build(BuildContext context) {
    // TODO: implement build
    return BlocProvider(
      create: (context) => SignUpCubit(),
      child: BlocConsumer<SignUpCubit, SignUpStates>(
        listener: (context, state) {},
        builder: (context, state) {
          SignUpCubit signUpCubit = SignUpCubit.get(context);
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            home: Scaffold(
                body: SafeArea(
              child: SingleChildScrollView(
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      orangeLogo(),
                      const SizedBox(
                        height: 50,
                      ),
                      SizedBox(
                        width: 350,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Text(
                                    "Sign Up",
                                    style: GoogleFonts.poppins(
                                        fontSize: 25,
                                        fontWeight: FontWeight.w600),
                                  ),
                                ],
                              ),
                              textFormFiled('Name', signUpCubit.name),
                              textFormFiled('E-Mail', signUpCubit.email),
                              textFormWithIcon(
                                  'Password',
                                  signUpCubit.pass1,
                                  const Icon(
                                    Icons.remove_red_eye,
                                    color: Colors.deepOrange,
                                  )),
                              textFormWithIcon(
                                  'Password',
                                  signUpCubit.pass2,
                                  const Icon(
                                    Icons.remove_red_eye,
                                    color: Colors.deepOrange,
                                  )),
                              textFormFiled('Phone Number', signUpCubit.phone),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Expanded(
                                    child: ListTile(
                                        title: Text("Gender",
                                            style: GoogleFonts.poppins(
                                                fontSize: 25,
                                                fontWeight: FontWeight.w300))),
                                  ),
                                  Expanded(
                                      child: ListTile(
                                    title: Text("University",
                                        style: GoogleFonts.poppins(
                                            fontSize: 25,
                                            fontWeight: FontWeight.w300)),
                                  ))
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 100,
                                    //margin: EdgeInsets.fromLTRB(100, 20, 199, 20),
                                    padding: const EdgeInsets.only(
                                        left: 00.0, right: 00.0),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.yellow, width: 2.0),
                                        borderRadius:
                                            BorderRadius.circular(15)),
                                    child: DropdownButton(
                                      hint: const Text("Female"),
                                      dropdownColor: Colors.white,
                                      elevation: 5,
                                      icon: const Icon(Icons.arrow_drop_down),
                                      iconSize: 36.0,
                                      isExpanded: true,
                                      value: gendervalue,
                                      onChanged: (value) {
                                        setState(() {
                                          gendervalue = value!;
                                        });
                                      },
                                      items: gender.map((value) {
                                        return DropdownMenuItem(
                                          value: value,
                                          child: Text(value),
                                        );
                                      }).toList(),
                                    ),
                                  ),
                                  const SizedBox(width: 100),
                                  Container(
                                    width: 100,
                                    padding: const EdgeInsets.only(
                                        left: 00.0, right: 00.0),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.yellow, width: 2.0),
                                        borderRadius:
                                            BorderRadius.circular(15)),
                                    child: DropdownButton(
                                      hint: const Text("ASU"),
                                      dropdownColor: Colors.white,
                                      elevation: 5,
                                      icon: const Icon(Icons.arrow_drop_down),
                                      iconSize: 36.0,
                                      isExpanded: true,
                                      value: UniVal,
                                      onChanged: (value) {
                                        setState(() {
                                          UniVal = value!;
                                        });
                                      },
                                      items: university.map((value) {
                                        return DropdownMenuItem(
                                          value: value,
                                          child: Text(value),
                                        );
                                      }).toList(),
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Column(
                                    children: [
                                      Text("Grade",
                                          style: GoogleFonts.poppins(
                                              fontSize: 25,
                                              fontWeight: FontWeight.w300)),
                                      const SizedBox(
                                        height: 10,
                                      ),
                                      Container(
                                        width: 130,
                                        decoration: BoxDecoration(
                                            border: Border.all(
                                                color: Colors.yellow,
                                                width: 2.0),
                                            borderRadius:
                                                BorderRadius.circular(15)),
                                        child: DropdownButton(
                                          hint: const Text("Grade1"),
                                          dropdownColor: Colors.white,
                                          elevation: 5,
                                          icon: const Icon(Icons.arrow_drop_down),
                                          iconSize: 36.0,
                                          isExpanded: true,
                                          value: gradVal,
                                          onChanged: (value) {
                                            setState(() {
                                              gradVal = value!;
                                            });
                                          },
                                          items: grade.map((value) {
                                            return DropdownMenuItem(
                                              value: value,
                                              child: Text(value),
                                            );
                                          }).toList(),
                                        ),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                              elevatedButton('Sign Up', () {
                                signUpCubit.signUser(context);
                              }),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: const [
                                  Expanded(
                                      child: Divider(
                                    color: Colors.black26,
                                    thickness: 2,
                                  )),
                                  SizedBox(width: 9),
                                  Text(
                                    "OR",
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w600),
                                  ),
                                  SizedBox(width: 9),
                                  Expanded(
                                      child: Divider(
                                    color: Colors.black26,
                                    thickness: 2,
                                  )),
                                ],
                              ),
                              elevatedButtonBorder('Login', true, context)
                            ]),
                      ),
                    ]),
              ),
            )),
          );
        },
      ),
    );
  }
}
