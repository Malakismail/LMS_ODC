import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:share_plus/share_plus.dart';

import 'ODCShow.dart';

class News extends StatelessWidget {
  const News({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: SafeArea(
          child: Scaffold(
            body: SingleChildScrollView(
              child: Column(children: [
                const SizedBox(
                  height: 20,
                ),
                Center(
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                      const SizedBox(height: 20),
                      Text("News",
                          style: GoogleFonts.poppins(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                              textStyle: const TextStyle(color: Colors.black)))
                    ])),
                const SizedBox(height: 20),
                Center(
                    child: Material(
                  color: Colors.white60,
                  elevation: 8,
                  borderRadius: BorderRadius.circular(16),
                  child: InkWell(
                    splashColor: Colors.black12,
                    child: Ink.image(
                        image: const AssetImage("assets/images/logo.png"),
                        height: 265,
                        width: 320,
                        fit: BoxFit.cover,
                        child: Column(
                          children: [
                            const SizedBox(height: 15),
                            Row(
                              children: [
                                const SizedBox(width: 10),
                                const Text("ODCS",
                                    style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold)),
                                const SizedBox(width: 132),
                                Container(
                                    width: 113,
                                    height: 40,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(7),
                                        color: Colors.deepOrangeAccent),
                                    child: Row(
                                      children: [
                                        //Icon(Icons.share_outlined,color: Colors.white)
                                        //const SizedBox(width: 8),
                                        IconButton(
                                            onPressed: ()async{
                                              await Share.share("https://www.orangedigitalcenters.com/");
                                            },
                                            icon: Icon(Icons.share_outlined,color: Colors.white,size: 20)),
                                        const VerticalDivider(
                                            color: Colors.white,
                                            thickness: .5,
                                            indent: 6,
                                            endIndent: 6),
                                        InkWell(
                                          child: SvgPicture.asset(
                                            "assets/icons/copy.svg",
                                            color: Colors.white,
                                          ),
                                          onTap: () => {
                                            Fluttertoast.showToast(
                                              msg: "Copied",
                                              toastLength: Toast.LENGTH_LONG,
                                              gravity: ToastGravity.TOP,
                                              timeInSecForIosWeb: 1,
                                              backgroundColor: Colors.blue,
                                              textColor: Colors.white,
                                              fontSize: 20.0,
                                            )
                                          },
                                        ),
                                      ],
                                    ))
                              ],
                            ),
                            const SizedBox(height: 180),
                            Row(
                              children: const [
                                SizedBox(width: 10),
                                Text("ODC Supports All Universities",
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w300,
                                        color: Colors.black)),
                                SizedBox(width: 10),
                              ],
                            )
                          ],
                        )),
                    onTap: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => ODCShow()));
                    },
                  ),
                )),
              ]),
            ),
          ),
        ));
  }
}
