import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

import '../Component/Home/CardLectureComnent.dart';
import '../view_model/Block/Lecture/Lecture_Cubit.dart';
import '../view_model/Block/Lecture/Lecture_States.dart';
import 'navigator_barLayout.dart';


class Lecture extends StatelessWidget {
  const Lecture({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (context) => LectureCubit()..getLectureData(),
        child: BlocConsumer<LectureCubit, LectureStates>(
          listener: (context, state) {},
          builder: (context, state) {
            LectureCubit lectureCubit = LectureCubit.get(context);
            return MaterialApp(
                home: Scaffold(
                  appBar: AppBar(
                      backgroundColor: Colors.white,
                      leading: InkWell(
                        onTap: () => Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => const NavBarLayout())),
                        child: const Icon(
                          Icons.arrow_back_ios,
                          color: Colors.deepOrange,
                        ),
                      ),
                      centerTitle: true,
                      title: Text(
                        "Lectures",
                        style: GoogleFonts.poppins(
                          fontSize: 24,
                          fontWeight: FontWeight.w600,
                          textStyle: const TextStyle(
                            color: Colors.black,
                          ),
                        ),
                      ),
                      actions: [
                        PopupMenuButton(
                            icon: const Icon(
                              Icons.filter_alt,
                              color: Colors.deepOrange,
                            ),
                            itemBuilder: (context) => [
                              PopupMenuItem(
                                value: 1,
                                child: Text("All Sections",
                                    style: GoogleFonts.poppins(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w400,
                                      textStyle: const TextStyle(
                                          color: Colors.black,
                                          letterSpacing: .5),
                                    )),
                              ),
                              PopupMenuItem(
                                value: 2,
                                child: Text("Finished Sections",
                                    style: GoogleFonts.poppins(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w400,
                                      textStyle: const TextStyle(
                                          color: Colors.black,
                                          letterSpacing: .5),
                                    )),
                              ),
                              PopupMenuItem(
                                value: 2,
                                child: Text("Remaining Sections",
                                    style: GoogleFonts.poppins(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w400,
                                      textStyle: const TextStyle(
                                          color: Colors.black,
                                          letterSpacing: .5),
                                    )),
                              )
                            ])
                      ]),
                  body: Container(
                      child: lectureCubit.lectureModel == null
                          ? const Center(
                        child: CircularProgressIndicator(
                            color: Colors.deepOrangeAccent),
                      )
                          : ListView.builder(
                        shrinkWrap: true,
                        itemCount: lectureCubit.lectureModel!.data!.length,
                        itemBuilder: ((context, index) {
                          return lectureCard(
                              lectureCubit
                                  .lectureModel!.data![index].lectureSubject
                                  .toString(),
                              lectureCubit
                                  .lectureModel!.data![index].lectureDate
                                  .toString(),
                              lectureCubit
                                  .lectureModel!.data![index].lectureStartTime
                                  .toString(),
                              lectureCubit
                                  .lectureModel!.data![index].lectureEndTime
                                  .toString());
                        }),
                      )),
                ));
          },
        ));
  }
}
