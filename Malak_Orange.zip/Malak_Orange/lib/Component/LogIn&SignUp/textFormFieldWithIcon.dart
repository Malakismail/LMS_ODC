import 'package:flutter/material.dart';

Widget textFormWithIcon(
    String txt, TextEditingController editingController, Icon icon) {
  return Container(
    margin: const EdgeInsets.fromLTRB(0, 10, 0, 10),
    width: 350,
    child: TextFormField(
      obscureText: true,
      controller: editingController,
      decoration: InputDecoration(
          labelText: txt,
          suffixIcon: icon,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          focusedBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(5)),
              borderSide: BorderSide(color: Colors.deepOrangeAccent))),
    ),
  );
}
