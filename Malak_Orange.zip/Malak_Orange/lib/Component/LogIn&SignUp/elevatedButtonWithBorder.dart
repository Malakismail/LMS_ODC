import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../Pages/Login.dart';
import '../../Pages/SignUp.dart';

Widget elevatedButtonBorder(String text, bool flag, BuildContext context) {
  return Container(
    width: 350,
    height: 45,
    margin: const EdgeInsets.fromLTRB(0, 20, 0, 20),
    decoration: BoxDecoration(
        border: Border.all(color: Colors.deepOrangeAccent, width: 3),
        borderRadius: BorderRadius.circular(7)),
    child: ElevatedButton(
      onPressed: () {
        if (flag == false) {
          flag = true;
          Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) => SignUp()));
        } else {
          flag = false;
          Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) => Login()));
        }
      },
      style: const ButtonStyle(
        backgroundColor: MaterialStatePropertyAll<Color>(Colors.white),
      ),
      child: Text(
        text,
        style: GoogleFonts.poppins(
          fontSize: 18,
          fontWeight: FontWeight.w700,
          color: Colors.deepOrangeAccent,
        ),
      ),
    ),
  );
}
