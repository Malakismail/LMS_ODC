import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';



Widget homeCard(SvgPicture icon, String text) {
  return SizedBox(
    width: 170,
    height: 120,
    child: Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      shadowColor: Colors.black,
      elevation: 10,
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        CircleAvatar(
            backgroundColor: Colors.grey[200], radius: 30, child: icon),
        const SizedBox(height: 10),
        Text(
          text,
          style: GoogleFonts.poppins(
              color: Colors.deepOrangeAccent,
              fontSize: 20,
              fontWeight: FontWeight.w600),
        )
      ]),
    ),
  );
}
