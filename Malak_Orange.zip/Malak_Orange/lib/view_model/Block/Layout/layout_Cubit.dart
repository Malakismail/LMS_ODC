import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../Pages/HomePage.dart';
import '../../../Pages/NewsPage.dart';
import '../../../Pages/SettingPage.dart';



part 'layout_State.dart';

class LayoutCubit extends Cubit<LayoutStates> {
  LayoutCubit() : super(LayoutInitialState());

  static LayoutCubit get(BuildContext context) => BlocProvider.of(context);
  List<Widget> list = [const Home(), const News(), const Setting()];
  int currentIndex = 0;

  void changeCurrent(int newIndex) {
    currentIndex = newIndex;
    emit(LayoutChange());
  }
}
