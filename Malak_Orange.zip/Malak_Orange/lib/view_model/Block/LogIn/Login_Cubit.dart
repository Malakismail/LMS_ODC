import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../Pages/navigator_barLayout.dart';
import '../../Database/network/dio_helper.dart';
import '../../Database/network/end_points.dart';
import 'Login_State.dart';

class LoginCubit extends Cubit<LoginState>
{
  LoginCubit() : super(LoginInitial());
  static LoginCubit get(BuildContext context) =>BlocProvider.of(context);
  TextEditingController emial=TextEditingController();
  TextEditingController password=TextEditingController();

  void loginUser(BuildContext context)
  {
    var data= {'email':emial.text,'password':password.text};
    DioHelper.postData(url: loginEndPoint, data: data).then((value) {
      print(value.data);
      print(value.statusCode);
      Navigator.push(context, MaterialPageRoute(builder: (context) => NavBarLayout(),));
    }).catchError((onError){
      print(onError);
    });
  }

}