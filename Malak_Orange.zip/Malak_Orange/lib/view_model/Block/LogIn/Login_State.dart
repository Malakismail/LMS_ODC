abstract class LoginState{}

class LoginInitial extends LoginState{}

class LoginSuccsess extends LoginState{}

class LoginFailed extends LoginState{}
