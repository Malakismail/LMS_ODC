
import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../Model/SectionsModel.dart';
import '../../../constant.dart';
import '../../Database/network/dio_helper.dart';
import '../../Database/network/end_points.dart';
import 'Section_States.dart';


class SectionCubit extends Cubit<SectionStates>
{
  SectionCubit() : super(SectionInitial());
  static SectionCubit get(BuildContext context) =>BlocProvider.of(context);
  SectionModel? sectionModel;
  void getSectionData()
  {
    DioHelper.getData(url: sectionEndPoint,token: token).then((value) {
       sectionModel =SectionModel.fromJson(value.data);
       print(sectionModel!.code);
       emit(SectionStoredData());
    });
  }
}