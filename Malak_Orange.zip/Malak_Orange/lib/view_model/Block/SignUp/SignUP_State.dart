
abstract class SignUpStates{}

class SignUpInitial extends SignUpStates{}

class SignUpSucssess extends SignUpStates{}

class SignUpFailed extends SignUpStates{}

