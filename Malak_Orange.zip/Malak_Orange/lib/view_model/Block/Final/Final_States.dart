
abstract class FinalStates{}

class FinaLInitial extends FinalStates{}

class FinaLStoredData extends FinalStates{}