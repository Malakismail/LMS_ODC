package com.example.malak_orange

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
